#pragma once

// Dołączenie nagłówka SDKDDKVer.h definiuje najwyższą dostępną platformę systemu Windows.

// Jeśli chcesz skompilować aplikację dla wcześniejszej platformy systemu Windows, dołącz nagłówek WinSDKVer.h i
// ustaw makro _WIN32_WINNT na platformę, którą chcesz wspierać, przed dołączeniem nagłówka SDKDDKVer.h.

#include <SDKDDKVer.h>
