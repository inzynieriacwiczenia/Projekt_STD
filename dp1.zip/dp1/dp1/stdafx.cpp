// stdafx.cpp: plik źródłowy , który zawiera tylko standardowe zawarcia
// $safeprojectname$.pch będzie prekompilowanym nagłówkiem
// stdafx.obj będzie zawierać informacje typu wstępnie skompilowanego

#include "stdafx.h"

// TODO: odwołaj się do dowolnych dodatkowych nagłówków, których potrzebujesz w pliku STDAFX.H
// a nie w tym pliku
